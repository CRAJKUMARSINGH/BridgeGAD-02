import pandas as pd
import os
from openpyxl import load_workbook
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from datetime import datetime, timedelta
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, PageBreak
from num2words import num2words  # Import num2words
from reportlab.lib.pagesizes import A4, landscape, portrait


# File paths (Keep these at the top)
input_file = r"F:\0MyAppsPython\ELECTRIC DIVISION\goodfor4.xlsx"
output_excel = r"F:\0MyAppsPython\ELECTRIC DIVISION\goodfor4_output.xlsx"
output_pdf = r"F:\0MyAppsPython\ELECTRIC DIVISION\goodfor4_Documents.pdf"

# 1. Data Loading and Processing (FIRST)
try:
    df = pd.read_excel(input_file, engine='openpyxl')
    df.columns = df.columns.str.strip().str.upper()
except FileNotFoundError:
    print(f"Error: Input file '{input_file}' not found.")
    exit()
except Exception as e:
    print(f"Error reading Excel file: {e}")
    exit()

# ... (Data processing logic - same as before)
estimated_cost_col = "ESTIMATED COST"
date_received_col = "DATE OF RECEIPT OF TENDER"
bidder_prefix = "BIDDER"
rate_prefix = "RATE"

bidder_cols = [col for col in df.columns if col.startswith(bidder_prefix)]
rate_cols = [col for col in df.columns if col.startswith(rate_prefix)]

required_cols = [estimated_cost_col, date_received_col, 'NAME OF WORK', 'NIT NO.'] + bidder_cols + rate_cols
if not all(col in df.columns for col in required_cols):
    missing_cols = set(required_cols) - set(df.columns)
    print(f"Error: Missing required columns: {', '.join(missing_cols)}")
    exit()

# Convert to Numeric/Datetime
df[estimated_cost_col] = pd.to_numeric(df[estimated_cost_col], errors='coerce')
df[date_received_col] = pd.to_datetime(df[date_received_col], errors='coerce')
# Convert the 'DATE' column to datetime objects
df['DATE'] = pd.to_datetime(df['DATE'], errors='coerce')  # errors='coerce' handles invalid date formats by setting them to NaT

# Fill NaN (carefully consider the best strategy for your data)
for col in bidder_cols + rate_cols:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna("")  # Assign the result back to the column
    else:
        df[col] = df[col].fillna(0)    # Assign the result back to the column
########################################################################################
# Normalize column names to avoid header mismatches
df.columns = df.columns.str.strip().str.upper()

# Find correct column names dynamically
estimated_cost_col = next((col for col in df.columns if "ESTIMATED COST" in col), None)
date_received_col = next((col for col in df.columns if "DATE OF RECEIPT OF TENDER" in col), None)
nit_no_col = next((col for col in df.columns if "NIT NO" in col), None)


comparative_data = []
for index, row in df.iterrows():  # ✅ Correctly retrieve each row
    nit_no = row.get("NIT NO.", "")
    work_name = row.get("WORK NAME", "")
    estimated_cost = row.get("ESTIMATED COST", 0)
    date_received = row.get("DATE RECEIVED", "")
    time_in_months = row.get("TIME IN MONTHS", "")  # ✅ Fix: Properly retrieve column value

    bidder_data = []
    for i in range(1, 8):  # Up to 7 bidders
        bidder_col_name = f"BIDDER{i}"
        rate_col_name = f"RATE{i}"

        if bidder_col_name in df.columns and rate_col_name in df.columns:
            bidder_name = row[bidder_col_name]
            quoted_percentage = row[rate_col_name]

            if pd.notna(quoted_percentage):
                quoted_percentage = float(quoted_percentage)
                amount_in_rs = estimated_cost + (estimated_cost * quoted_percentage / 100)
                bidder_data.append([i, bidder_name, estimated_cost, quoted_percentage, amount_in_rs])

    # Sort bidders based on quoted amount
    bidder_data.sort(key=lambda x: x[4])
    lowest_bidder = bidder_data[0] if bidder_data else None
    lowest_bid_rate = lowest_bidder[3] if lowest_bidder else None

    # Append to comparative data
    comparative_data.append({
        "nit_no": nit_no,
        "work_name": work_name,
        "estimated_cost": estimated_cost,
        "date_received": date_received,
        "time_in_months": time_in_months,  # ✅ Now correctly stored
        "bidders": bidder_data,
        "lowest_bidder": lowest_bidder,
        "lowest_bid_rate": lowest_bid_rate
    })

#############################################################################################
##################################################
def create_comparative_table(data):
    
    styles = getSampleStyleSheet()
    style = styles["Normal"]
    table_data = [['S.No', 'Bidder Name', 'Estimated Cost', 'Quoted Percentage', 'Amount in Rs']]
    for row in data:
        table_data.append(row)
    table = Table(table_data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 4),
        ('TOPPADDING', (0, 0), (-1, -1), 2),  # Minimize top padding
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    return table
#####################################################################from reportlab.lib import colors
def create_notesheet_table(data):
    styles = getSampleStyleSheet()
    style = styles["Normal"]

    table_data = [
        ["S. No.", "Description", "Details"]
    ]

    for row in data:
        # Add double line break for items 2, 13, and 14
        if row[0] in ("2", "13", "14"):
            details = row[2].replace('\n', '<br/>')  # Use <br/> for line breaks in Paragraph
            details_paragraph = Paragraph(details, style)  # Wrap in Paragraph
            # Ensure vertical alignment for rows 2, 13, and 14
            table_data.append([row[0], Paragraph(row[1], style), details_paragraph])
        else:
            
            table_data.append(row)

    # Define column widths (shrink the first column by 50%)
    col_widths = [30, 220, 250]  # Adjusted: First column reduced from 40 to 30

    table = Table(table_data, colWidths=col_widths, hAlign='LEFT')  # Apply column widths

    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('WORDWRAP', (0, 0), (-1, -1), True),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),  
        ('LEADING', (0, 0), (-1, -1), 12),      
        ('VALIGN', (0, 1), (0, -1), 'TOP'),  # Align "Item No." column to top
        ('VALIGN', (1, 1), (1, -1), 'TOP'),  # Align "Description" column to top
        ('VALIGN', (2, 1), (2, -1), 'TOP')   # Align "Details" column to top
    ]))

    # Create a list to hold table and additional elements
    elements = [table]

    

    # ✅ Add Note Sheet Elements Below Main Content
    note_sheet_elements = [
        "The bid of the lowest bidder may be appraised for approval."
    ]

    for note in note_sheet_elements:
        elements.append(Paragraph(f"• {note}", styles['Normal']))
        elements.append(Spacer(1, 4))  # Small space between note items

    elements.append(Spacer(1, 10))  # Extra space before signatures

    # ✅ Add signature lines (adjust positions as needed)
    signatures = [
        ("AUDITOR", "DIV. ACCOUNTANT", "Tech. Asst.", "EXECUTIVE ENGINEER"),
        ("(Premlata Jain, AAO)", "(Babu Lal Sharma)", "(Ajay Kumawat)", "(Sohan Lal Mehta)")
    ]

    for sig_row in signatures:
        sig_table_data = [[Paragraph(sig, styles['Normal']) for sig in sig_row]]
        sig_table = Table(sig_table_data, colWidths=[125, 125, 125, 125])  # Adjust colWidths as needed
        sig_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('TOPPADDING', (0, 0), (-1, -1), 10)  # Add space above text
        ]))
        elements.append(sig_table)
        elements.append(Spacer(1, 6))  # Add space between signature rows

    return elements  # ✅ Return the final list of elements
######################################################################################################
def create_work_order_content(data, date_received, lowest_bidder_name):
    styles = getSampleStyleSheet()
    style = styles["Normal"]
    
    elements = []

    # Helper function to create underlined paragraphs (if still needed)
    def underlined(text, spacing=12):
        return Paragraph(f'<underline>{text}</underline>', style)

    # Header
    elements.append(Paragraph("<b>OFFICE OF THE EXECUTIVE ENGINEER PWD ELECTIC DIVISION UDAIPUR</b>", styles['h2']))
    elements.append(Spacer(1, 6))

    header_table = Table([
        [Paragraph("<b>REGISTERED A.D.</b>", style), Paragraph(f'<b>Date:</b> {date_received.strftime("%d-%m-%Y") if date_received else ""}', style)]
    ], 
    colWidths=[100, 150])
    header_table.setStyle(TableStyle([('ALIGN', (0, 0), (-1, -1), 'LEFT')]))
    elements.append(header_table)

    elements.append(Spacer(1, 12))

    elements.append(Paragraph(f'<b>M/S</b> {lowest_bidder_name}', style))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph("<b>Email :-</b>", style))  # If you want to include email, add data[‘email’]
    elements.append(Spacer(1, 18))

    # Main Content
    elements.append(Paragraph("<b>WRITTEN ORDER TO COMMENCE WORK</b>", styles['h2']))
    elements.append(Spacer(1, 12))

    elements.append(Paragraph(f'<b>Name of Work :-</b> {data.get("name_of_work", "_"*50)}', style))  # Use data.get
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Job No. :-</b> {"_"*50}', style))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>NIT No :-</b> {data.get("nit_no", "_"*20)} <b>{" "*20}Item no.---</b> {data.get("item_no", "_"*20)}', style))   
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Ref.:- Your Tender/Negotiations dated :-</b> {date_received.strftime("%d-%m-%Y") if date_received else "_"*20}', style))
    elements.append(Spacer(1, 12))
    elements.append(Paragraph("Sir,", style))
    elements.append(Spacer(1, 12))
    lowest_bidder_rate_display = data.get('lowest_bidder_rate', 'N/A') # Get it from the data or provide a default

    elements.append(Paragraph(f"Your tender for the above work has been accepted on behalf of the Governor of Rajasthan @ lowest_bidder_rate_display %   the Schedule 'G' amounting to  only)", style))


    elements.append(Paragraph("You are therefore, requested to please contact the Assistant Engineer-in-Charge of the Work and start the work.", style))
    elements.append(Spacer(1, 12))
    elements.append(Paragraph("The time allowed for commencement of work shall be reckoned form 1st days after the date of this order. Including tender document shall form part agreement and treated as executed between you and the Governor of Rajasthan.", style))
    elements.append(Spacer(1, 12))
    
    elements.append(Paragraph(f'<b>Agreement No:-</b> {data.get("agreement_no", "None")} <b>Year:-</b> {data.get("year", "None")}', style))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Stipulated date for commencement of work :-</b> {(date_received + timedelta(days=10)).strftime("%d-%m-%Y") if date_received else "_"*20}', style))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Stipulated date for completion of work:-</b> {data.get("completion_date", "_"*20)} <b>Month:-</b> {data.get("completion_month", "_"*20)}', style))  # Corrected
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Administrative Sanction:-</b> {data.get("administrative_sanction", "_"*20)} <b>date</b> {data.get("administrative_date", "_"*20)} <b>Rs</b> {data.get("administrative_amount", "_"*20)} <b>Lac</b> {data.get("administrative_lac", "_"*20)}', style))  # Corrected
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Technical Sanction:-</b> {data.get("technical_sanction", "_"*20)} <b>TS/-</b> {data.get("ts_number", "_"*20)} <b>Date</b> {data.get("technical_date", "_"*20)} <b>Rs</b> {data.get("technical_amount", "_"*20)} <b>Lac</b> {data.get("technical_lac", "_"*20)}', style))  # Corrected
    elements.append(Spacer(1, 6))
    elements.append(Paragraph(f'<b>Budget Provision :-</b> {data.get("budget_provision", "_"*20)}', style))
    elements.append(Spacer(1, 12))

    elements.append(Paragraph("<b>Yours Faithfully,</b>", style))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph("<b>Executive Engineer</b>", style))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph("<b>On behalf of the Governor of State of Rajasthan</b>", style))
    elements.append(Spacer(1, 18))

    elements.append(Paragraph(f'<b>No.</b> {data.get("work_order_no", "_"*20)} <b>Dated.........</b>', style))  # Corrected
    elements.append(Spacer(1, 18))

    elements.append(Paragraph("Copy to the following for information & necessary action:-", style))
    elements.append(Spacer(1, 6))

    elements.append(Paragraph("Copy to the following for information & necessary action:-", style))
    elements.append(Spacer(1, 6))

    # Fixed "Copy to" addresses
    elements.append(Paragraph("1. The Accountant General Rajasthan,  Jaipur", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("2. The Addl Chief Engineer, PWD Zone, Udaipur.", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("3. The Addl Chief Engineer, PWD Electrical Zone, Udaipur.", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("4. The Superintending Engineer, PWD Electric Circle,Udaipur.", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("5. The Assistant Engineer, PWD Electric Sub.Dn.- I/II Udaipur/Rajsamand for similar action.", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("6. The Junior Engineer, PWD Electric Sub Dn I/II Udaipur/Rajsamand for similar action.", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("7. Agreement clerk with original tender for preparing agreement at the earliest.", style))
    elements.append(Spacer(1, 3))
    elements.append(Paragraph("8. Auditor .......", style))
    elements.append(Spacer(1, 18))  # Increased space after "Copy to"

    elements.append(Paragraph("The Executive Engineer<br/>PWD Electric Dn., Udaipur", style))

    return elements
##################################################################################
# #################################################
def save_to_excel(filename, comparative_data):
    if not comparative_data:
        print("Warning: No comparative data to save. Creating an empty Excel file.")
        df_empty = pd.DataFrame({'A': []})
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            df_empty.to_excel(writer, index=False, sheet_name="Sheet1")
        return

    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        first_sheet_name = None
        for i, item in enumerate(comparative_data):
            nit_no = item['nit_no']
            work_name = item['work_name']
            estimated_cost = item['estimated_cost']
            bidders = item['bidders']
            lowest_bidder = item['lowest_bidder']
            lowest_bid_rate = item.get('lowest_bidder_rate')
            estimated_cost = item.get('estimated_cost')

            lowest_bid_amount = None
            lowest_bid_amount_words = None

            if lowest_bid_rate is not None and estimated_cost is not None:
                try:
                    discount_percentage = float(lowest_bid_rate)  # Convert to float *here*
                    lowest_bid_amount = float(estimated_cost) * (1 + discount_percentage / 100)
                    lowest_bid_amount = round(lowest_bid_amount, 2)
                    lowest_bid_amount_words = num2words(lowest_bid_amount)
                except ValueError:
                    print("Error: Could not convert lowest_bidder_rate or estimated_cost to a number.")

            # Create DataFrame for Comparative Statement
            df_comparative = pd.DataFrame(bidders, columns=['S.No', 'Bidder Name', 'Estimated Cost', 'Quoted Percentage', 'Amount in Rs'])

            

            # Create DataFrame for Notesheet
            notesheet_data = [
                ["Item No.", "Description", "Details"]
            ]
            notesheet_data.extend([  # Add data rows
                ["1", "Head of Account", ""],
                ["2", "Name of work with Job No.", work_name],
                ["5", "Date of calling NIT", df.loc[df['NIT NO.'] == nit_no, 'DATE'].iloc[0].strftime("%d-%m-%Y")],
                ["6", "Date of receipt of tender", df.loc[df['NIT NO.'] == nit_no, 'DATE OF RECEIPT OF TENDER'].iloc[0].strftime("%d-%m-%Y")],
                ["7", "No. of tender sold", df.loc[df['NIT NO.'] == nit_no, 'NO. OF TENDER SOLD'].iloc[0]],
                ["8", "No. of tender received", df.loc[df['NIT NO.'] == nit_no, 'NO. OF TENDER RECEIVED'].iloc[0]],
                ["11", "Lowest rate quoted and condition if any", f"{lowest_bidder[3]}%" if lowest_bidder else ""],
                ["15", "Validity of tender", (df.loc[df['NIT NO.'] == nit_no, 'DATE OF RECEIPT OF TENDER'].iloc[0] + timedelta(days=15)).strftime("%d-%m-%Y") if lowest_bidder else ""],
                # ... other Notesheet data
            ])
            df_notesheet = pd.DataFrame(notesheet_data[1:], columns=notesheet_data[0]) # Skip header row

            # Save to Excel (OUTSIDE the if block)
            sheet_name_comparative = f"Comparative_{nit_no}"
            df_comparative.to_excel(writer, index=False, sheet_name=sheet_name_comparative)

            sheet_name_notesheet = f"Notesheet_{nit_no}"
            df_notesheet.to_excel(writer, index=False, sheet_name=sheet_name_notesheet)

            if i == 0:
                first_sheet_name = sheet_name_comparative # Capture the sheet name


        if first_sheet_name:
            writer.sheets[first_sheet_name].active = True
        else:
            print("Warning: No sheets were created. Cannot activate a sheet.")
#########################################################################################################
# ##############################################
def create_document(filename, comparative_data, nit_no):
#def create_document(output_pdf, comparative_data, nit_no):
    from reportlab.lib.styles import getSampleStyleSheet
    styles = getSampleStyleSheet()  # ✅ Define styles

    if not filename:
        print("Error: filename is not defined")
        return
    
    print(f"Generating document: {filename}")
    
    doc = BaseDocTemplate(filename, pagesize=A4)  # Ensure filename is set properly


    try:
        date_obj = df.loc[df['NIT NO.'] == nit_no, 'DATE'].iloc[0]

        formatted_date = date_obj.strftime("%d-%m-%Y") if pd.notna(date_obj) else ""
    except (IndexError, AttributeError):
        formatted_date = ""
    doc = BaseDocTemplate(filename, pagesize=A4,
                        leftMargin=25*mm, rightMargin=25*mm,
                        topMargin=10*mm, bottomMargin=15*mm)

    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='normal')
    doc.addPageTemplates([PageTemplate(id='main', frames=[frame])])

    story = []  # Holds ALL the document content
    for item in comparative_data:

        nit_no = item['nit_no']
        work_name = item['work_name']
        estimated_cost = item['estimated_cost']
        bidders = item['bidders']
        lowest_bidder = item.get('lowest_bidder')
        date_received_str = item.get('date_received')
        validity_date = date_received + timedelta(days=15) if date_received else None
        lowest_bid_rate = item.get('lowest_bidder_rate')
        estimated_cost = item.get('estimated_cost')

        lowest_bid_amount = None
        lowest_bid_amount_words = None
        discount_percentage = None # Initialize discount_percentage outside the if block

        if lowest_bid_rate is not None and estimated_cost is not None:
            try:
                discount_percentage = float(lowest_bid_rate)
                lowest_bid_amount = float(estimated_cost) * (1 + discount_percentage / 100)
                lowest_bid_amount = round(lowest_bid_amount, 2)
                lowest_bid_amount_words = num2words(lowest_bid_amount)
            except ValueError:
                print("Error: Could not convert lowest_bidder_rate or estimated_cost to a number.")

    # 1. Comparative Statement (Landscape) - Start of Landscape Section
        doc.pagesize = landscape(A4)  # Set page size to landscape
        landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='landscape')  # Define the frame
        landscape_template = PageTemplate(id='landscape', frames=[landscape_frame], pagesize=landscape(A4)) # Define the template
        doc.addPageTemplates([landscape_template]) # Add the template
        story.append(PageBreak()) # Add a page break to apply the template

        story.append(Paragraph(f"<b>Comparative Statement for NIT No: {nit_no} - {work_name}</b>", styles['h2']))
        if bidders:
            comparative_table = create_comparative_table(bidders)
            story.append(comparative_table)
        story.append(Spacer(1, 6))
    # 2. Notesheet (Portrait) - Start of Portrait Section
        doc.pagesize = A4  # Set page size to portrait
        portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait')
        portrait_template = PageTemplate(id='portrait', frames=[portrait_frame], pagesize=A4)
        doc.addPageTemplates([portrait_template])
        story.append(PageBreak()) # Add a page break to apply the template
        notesheet_data = [
            ["1", "Head of Account", ""],  # Fill in the actual value
            ["2", "Name of Work with Job No.", f"{work_name}"],
            ["3", "Reference of ADM. Sanction and amount", ""], # Fill in
            ["4", "Reference of technical sanction with amount", ""], # Fill in
            ["5", "Date of calling NIT", formatted_date],
            ["6", "Date of Receipt of Tender", date_received.strftime("%d-%m-%Y") if date_received else ""],
            ["7", "No. of Tenders sold", df.loc[df['NIT NO.'] == nit_no, 'NO. OF TENDER SOLD'].iloc[0] if (df.loc[df['NIT NO.'] == nit_no, 'NO. OF TENDER SOLD'].size > 0) else ""],
            ["8", "No. of Tender/s received", df.loc[df['NIT NO.'] == nit_no, 'NO. OF TENDER RECEIVED'].iloc[0] if (df.loc[df['NIT NO.'] == nit_no, 'NO. OF TENDER RECEIVED'].size > 0) else ""],
            ["9", "Allotment of fund in the current financial year", " Adequete."], # Fill in
            ["10", "Expenditure up to last bill", "Not Applicable."], # Fill in
            ["11", "Lowest rate quoted and condition if any",
                f"{lowest_bidder[3]}% (Minus indicates below Schedule G. No Condition.)" if lowest_bidder and lowest_bidder[3] < 0 
                else f"{lowest_bidder[3]}% No Condition." if lowest_bidder 
                else "No Condition."],

            ["12", "Financial implication of condition if any in tender", "None."], # Fill in
            ["13", "Name of the lowest Bidder/ contractor", lowest_bidder[1] if lowest_bidder else ""], # Get from comparative data
            ["14", "Authority competent to sanction the tender", "The Executive Engineer, PWD Electric Division, Udaipur"], # Fill in
            ["15", "Validity of tender (15 Days) upto", validity_date.strftime("%d-%m-%Y") if validity_date else ""],
            ["16", "Remarks if any", "None."]  # Fill in or make it dynamic
        ]
        story.append(Paragraph('<u><b>Scrutiny Sheet of Tender</b></u>', styles['Title']))

        notesheet_elements = create_notesheet_table(notesheet_data)
        story.extend(notesheet_elements)  # Now works correctly
        story.append(Spacer(1, 6))
        story.append(PageBreak())  # Add a page break
        
    # 3. Work Order (Portrait)
        doc.pagesize = A4
        work_order_data = {  # Initialize the dictionary *once*
                           # ... other data
            "lowest_bidder_rate": lowest_bid_rate,
            "lowest_bidder_amount": lowest_bid_amount,
            "lowest_bidder_amount_words": lowest_bid_amount_words,
            "discount_percentage": discount_percentage, # Add discount_percentage to the dictionary
            # ... other data
            "name_of_work": item.get('work_name'),
            "job_no": "         ",
            "nit_no": item.get('nit_no'),
            "item_no": item.get('item_no'),
            "email": item.get('email'),
            "governor_acceptance": item.get('governor_acceptance'),
            "schedule_g_amount": item.get('estimated_cost'),
            "schedule_g_lowest_amount": lowest_bidder[4] if lowest_bidder and len(lowest_bidder) > 4 else "",
            "agreement_no": item.get('agreement_no'),
            "year": item.get('year'),
            "completion_date": item.get('completion_date'),
            "completion_month": item.get('completion_month'),
            "administrative_sanction": item.get('administrative_sanction'),
            "administrative_date": item.get('administrative_date'),
            "administrative_amount": item.get('administrative_amount'),
            "administrative_lac": item.get('administrative_lac'),
            "technical_sanction": item.get('technical_sanction'),
            "ts_number": item.get('ts_number'),
            "technical_date": item.get('technical_date'),
            "technical_amount": item.get('technical_amount'),
            "technical_lac": item.get('technical_lac'),
            "budget_provision": item.get('budget_provision'),
            "work_order_no": item.get('work_order_no'),
            "copy_to": item.get('copy_to'),
            "lowest_bidder_rate": lowest_bid_rate,  # Store the original rate (can be None)
            "lowest_bidder_amount": lowest_bid_amount,
            "lowest_bidder_amount_words": lowest_bid_amount_words,
        }


        story.append(Paragraph("<b>WRITTEN ORDER TO COMMENCE WORK</b>", styles['h2']))
        work_order_elements = create_work_order_content(work_order_data, date_received, lowest_bidder)
        story.extend(work_order_elements)
        story.append(Spacer(1, 6))

##############################################
    doc.build(story) # Build the document outside the loop
# 3. Call create_document and save_to_excel (LAST)
create_document(output_pdf, comparative_data, nit_no)


save_to_excel(output_excel, comparative_data)

print("PDF and Excel files generated successfully!")